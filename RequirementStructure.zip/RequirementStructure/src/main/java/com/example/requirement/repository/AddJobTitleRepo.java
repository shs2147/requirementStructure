package com.example.requirement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.requirement.entity.AddJobTitle;

public interface AddJobTitleRepo extends JpaRepository<AddJobTitle, Integer> {

}
