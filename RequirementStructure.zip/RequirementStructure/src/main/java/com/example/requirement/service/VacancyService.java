package com.example.requirement.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.requirement.dto.VacancyDto;
import com.example.requirement.entity.Vacancy;
import com.example.requirement.repository.VacancyRepo;

@Service
public class VacancyService {
	
	@Autowired
	VacancyRepo repo;
	@Autowired
	 ModelMapper mapper;
	
	public Vacancy vacancyDtoTovacancy(VacancyDto vacancyDto) {
		Vacancy vacancy=this.mapper.map(vacancyDto, Vacancy.class);
		return vacancy;
//		Vacancy va=new Vacancy();
//		va.setId(vacancyDto.getId());
//		va.setHiringManager(vacancyDto.getHiringManager());
//		va.setJobDescription(vacancyDto.getJobDescription());
//		va.setJobLocation(vacancyDto.getJobLocation());
//		va.setJobTitle(vacancyDto.getJobTitle());
//		va.setNumberOfPosition(vacancyDto.getNumberOfPosition());
//		va.setVacancyName(vacancyDto.getVacancyName());
//	
//		return va;
	}
	public VacancyDto vacancyToVacancyDto(Vacancy vacancy) {
		VacancyDto dto=this.mapper.map(vacancy, VacancyDto.class);
		return dto;
	}
	

	public void vacancySave(VacancyDto vacancyDto) 
	{
		repo.save(vacancyDtoTovacancy(vacancyDto));
		
	}
}
