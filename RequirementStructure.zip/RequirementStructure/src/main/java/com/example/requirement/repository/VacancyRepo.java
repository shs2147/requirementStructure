package com.example.requirement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.requirement.entity.Vacancy;

public interface VacancyRepo extends JpaRepository<Vacancy,Integer>{

}
