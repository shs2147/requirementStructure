package com.example.requirement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.requirement.entity.Application;


@EnableJpaRepositories
public interface ApplicationRepo  extends JpaRepository<Application, Integer>{

	
}
