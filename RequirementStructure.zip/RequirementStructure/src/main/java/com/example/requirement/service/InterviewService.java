package com.example.requirement.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.requirement.dto.InterviewDto;
import com.example.requirement.entity.Interview;
import com.example.requirement.repository.InterviewRepo;

@Service
public class InterviewService {
	
	@Autowired
	InterviewRepo interviewRepo;
	
	@Autowired
	ModelMapper mapper;
	
	public Interview interviewDtoInterview(InterviewDto interviewDto) 
	{
		Interview interview=this.mapper.map(interviewDto, Interview.class);
		return interview;
		
	}
	
	public InterviewDto interviewToInterviewDto(Interview interview) 
	{
		InterviewDto interviewDto=this.mapper.map(interview, InterviewDto.class);
		return interviewDto;
	}
	
	public void saveInt(InterviewDto interviewDto) {
		interviewRepo.save(interviewDtoInterview(interviewDto));
	}

}
