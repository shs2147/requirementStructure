package com.example.requirement.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.requirement.dto.AddJobTitleDto;
import com.example.requirement.entity.AddJobTitle;
import com.example.requirement.repository.AddJobTitleRepo;

@Service

public class AddJobTitleService {
	
	@Autowired
	AddJobTitleRepo addJobTitleRepo;
	
	@Autowired
	ModelMapper mapper;
	
	public void saveTitle(AddJobTitleDto addJobTitleDto) {
		addJobTitleRepo.save(addJobTitleDtoToaddJobTitle(addJobTitleDto));
		
		
	}
	public List<AddJobTitleDto>getJob(){
		List<AddJobTitle>listJob=this.addJobTitleRepo.findAll();
		List<AddJobTitleDto>dtolist=listJob.stream().map(li -> this.jobToJobDto(li)).collect(Collectors.toList());
		return dtolist;
		
	}
	public List<AddJobTitleDto>getById(int id)
	{
	
		Optional<AddJobTitle>job=this.addJobTitleRepo.findById(id);
		List<AddJobTitleDto>addJob=job.stream().map(li -> this.jobToJobDto(li)).collect(Collectors.toList());
	
		return addJob;
	
	}

	public AddJobTitle addJobTitleDtoToaddJobTitle(AddJobTitleDto addJobTitleDto) {
	 
		AddJobTitle addJobTitle=this.mapper.map(addJobTitleDto, AddJobTitle.class);
		
		return addJobTitle;
	}
	
	public AddJobTitleDto jobToJobDto (AddJobTitle addJobTitle) {
		AddJobTitleDto addJobTitleDto=this.mapper.map(addJobTitle, AddJobTitleDto.class);
		return addJobTitleDto;
	}

}
