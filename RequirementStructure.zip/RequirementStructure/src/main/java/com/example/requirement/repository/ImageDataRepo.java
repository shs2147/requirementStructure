package com.example.requirement.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.requirement.entity.ImageData;



public interface ImageDataRepo extends JpaRepository<ImageData, Long>{
	  Optional<ImageData> findByName(String fileName);
}
