package com.example.requirement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddJobTitleDto {
	private int id;
	private String jobTitles;

	

}
