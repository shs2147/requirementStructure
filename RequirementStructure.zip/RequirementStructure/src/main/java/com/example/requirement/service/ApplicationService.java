package com.example.requirement.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.requirement.dto.ApplicationDto;
import com.example.requirement.entity.Application;
import com.example.requirement.repository.ApplicationRepo;

@Service
public class ApplicationService {

	@Autowired
	ApplicationRepo applicationRepo;
	
	@Autowired
	ModelMapper mapper;
	
	
	public Application appDtoToapp(ApplicationDto applicationDto) 
	{
		Application application=this.mapper.map(applicationDto, Application.class);
		return application;
		
	}
	public ApplicationDto appToAppDto(Application application) 
	{
		ApplicationDto app = this.mapper.map(application, ApplicationDto.class);
		return app;
	}
	
	
	public void svaeApp(ApplicationDto applicationDto) 
	{
		 applicationRepo.save(appDtoToapp(applicationDto));
		
		 
		
	}
}
