package com.ahom.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ahom.hrms.entity.AddJobTitle;

public interface AddJobTitleRepo extends JpaRepository<AddJobTitle, Integer> {

}
